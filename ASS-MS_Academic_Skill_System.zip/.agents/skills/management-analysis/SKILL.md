---
name: management-analysis
description: Menganalisis persoalan manajemen SDM, pemasaran, keuangan, operasi, strategi, kewirausahaan, dan organisasi.
---

# Management Analysis

## Ruang lingkup
- Manajemen sumber daya manusia dan perilaku organisasi
- Manajemen pemasaran dan perilaku konsumen
- Manajemen keuangan dan penganggaran
- Manajemen operasi dan rantai pasok
- Manajemen strategis dan tata kelola
- Kewirausahaan, UMKM, inovasi, dan model bisnis

## Kerangka analisis
1. Rumuskan masalah manajerial secara spesifik.
2. Identifikasi konteks organisasi, industri, pemangku kepentingan, dan batasan.
3. Pilih teori/kerangka yang relevan; jelaskan alasan pemilihannya.
4. Pisahkan fakta kasus dari asumsi.
5. Analisis sebab-akibat, alternatif, trade-off, risiko, dan implikasi.
6. Berikan rekomendasi yang dapat dilaksanakan, indikator keberhasilan, serta keterbatasannya.

## Alat analisis yang dapat dipertimbangkan
SWOT, PESTEL, Five Forces, VRIO, value chain, STP, marketing mix, customer journey, break-even analysis, budgeting, KPI, Balanced Scorecard, EOQ, process mapping, dan business model canvas.

Jangan menggunakan kerangka hanya sebagai hiasan. Terangkan input, interpretasi, dan relevansinya. Jangan memaksakan semua kerangka ke setiap kasus.

## Output
Ringkasan kasus, masalah utama, teori, analisis, alternatif, rekomendasi, risiko, KPI, dan pertanyaan diskusi.
