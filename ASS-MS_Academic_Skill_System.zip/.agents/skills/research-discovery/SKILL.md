---
name: research-discovery
description: Menemukan dan menilai literatur ilmiah, menyusun literature review, peta penelitian, dan research gap.
---

# Research Discovery

## Alur pencarian
1. Ubah topik menjadi pertanyaan pencarian dan konsep kunci.
2. Buat kata kunci Indonesia/Inggris, sinonim, dan kombinasi Boolean.
3. Prioritaskan artikel jurnal peer-reviewed, buku akademik, laporan resmi, dan sumber primer.
4. Catat basis data, tanggal pencarian, query, kriteria inklusi/eksklusi, dan alasan seleksi.
5. Verifikasi metadata artikel melalui laman penerbit, Crossref, DOI resolver, atau repositori resmi.
6. Baca abstrak dan teks lengkap sebelum menyimpulkan isi.
7. Sintesis temuan berdasarkan tema, metode, konteks, hasil, dan keterbatasan.

## Matriks literatur
Gunakan kolom: penulis/tahun, judul, konteks/sampel, teori, variabel/konsep, metode, hasil utama, keterbatasan, relevansi, DOI/URL terverifikasi.

## Research gap
Bedakan gap empiris, teoritis, metodologis, kontekstual, dan inkonsistensi temuan. Gap harus ditunjukkan melalui perbandingan sumber, bukan sekadar klaim "belum pernah diteliti".

## Larangan
Jangan mengarang artikel, hasil, jumlah sitasi, DOI, atau status indeksasi. Jika akses hanya abstrak, nyatakan keterbatasan tersebut. Jangan menyebut pencarian sistematis jika prosedurnya tidak terdokumentasi.

## Output
Strategi pencarian, kriteria seleksi, matriks literatur, sintesis tematik, gap yang didukung bukti, dan daftar sumber terverifikasi.
