---
name: business-case-study
description: Menganalisis kasus perusahaan, UMKM, organisasi, dan persoalan bisnis dengan teori serta rekomendasi manajerial.
---

# Business Case Study

## Kerangka
1. Ringkasan eksekutif.
2. Profil dan konteks organisasi.
3. Gejala, masalah inti, dan bukti.
4. Analisis lingkungan internal/eksternal.
5. Alternatif solusi dan kriteria evaluasi.
6. Rekomendasi dan rencana implementasi.
7. Risiko, kebutuhan sumber daya, KPI, dan kesimpulan.

## Standar analisis
- Gunakan data kasus dan sumber tepercaya.
- Pisahkan fakta, interpretasi, dan asumsi.
- Pertimbangkan dampak keuangan, pelanggan, karyawan, operasi, reputasi, dan keberlanjutan.
- Sertakan alternatif yang masuk akal, bukan hanya satu jawaban.
- Buat rekomendasi terukur: penanggung jawab, waktu, biaya/sumber daya, indikator, dan risiko.

Jangan mengarang kinerja perusahaan, laporan keuangan, atau kejadian. Tandai data yang belum tersedia.
