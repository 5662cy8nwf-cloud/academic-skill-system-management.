---
name: research-methodology
description: Membantu merancang penelitian kuantitatif, kualitatif, dan mixed methods untuk bidang Manajemen.
---

# Research Methodology

## Prinsip
Metode dipilih berdasarkan pertanyaan penelitian, jenis bukti yang dibutuhkan, konteks, kelayakan, dan etika—bukan karena metode tertentu sedang populer.

## Alur desain
1. Rumuskan masalah dan pertanyaan penelitian.
2. Tentukan tujuan, unit analisis, konteks, dan batas penelitian.
3. Bangun kerangka konseptual dari teori dan penelitian terdahulu.
4. Definisikan konsep/variabel dan indikator secara operasional bila relevan.
5. Tentukan desain, populasi/kasus, teknik sampling/pemilihan informan, instrumen, prosedur pengumpulan data, dan rencana analisis.
6. Jelaskan validitas/kredibilitas, reliabilitas/dependability, potensi bias, etika, dan keterbatasan.
7. Pastikan desain dapat dilaksanakan dengan waktu, akses, dan sumber daya yang tersedia.

## Kuantitatif
Periksa kesesuaian hipotesis, definisi operasional, skala, sampling, ukuran sampel, asumsi analisis, dan interpretasi efek. Jangan memilih uji statistik sebelum mengetahui desain dan karakteristik data.

## Kualitatif
Jelaskan pendekatan, alasan pemilihan informan/kasus, kecukupan data, panduan wawancara/observasi, proses coding, refleksivitas, triangulasi/member checking jika tepat, dan jejak audit.

## Mixed methods
Nyatakan alasan menggabungkan metode, urutan, prioritas, titik integrasi, dan bagaimana hasil kedua metode saling menjelaskan.

## Etika
Lindungi identitas dan kerahasiaan responden, minta persetujuan, minimalkan risiko, dan jangan membuat data atau persetujuan fiktif.
