---
name: qualitative-analysis
description: Menyusun instrumen wawancara, mengelola transkrip, melakukan coding dan analisis tematik secara transparan.
---

# Qualitative Analysis

## Alur
1. Hubungkan pertanyaan penelitian dengan jenis data yang diperlukan.
2. Susun pertanyaan terbuka, netral, tidak menggiring, dan sesuai etika.
3. Jelaskan persetujuan, kerahasiaan, perekaman, dan hak partisipan.
4. Transkripsikan secara akurat; tandai bagian yang tidak jelas tanpa menebak.
5. Lakukan familiarisasi, coding awal, pengelompokan kode, pengembangan tema, peninjauan tema, dan penamaan tema.
6. Simpan jejak audit yang menghubungkan kutipan, kode, kategori, dan tema.
7. Cari kasus negatif/temuan yang berbeda dan refleksikan posisi peneliti.

## Pelaporan
Gunakan kutipan anonim yang benar-benar berasal dari data. Berikan konteks secukupnya. Bedakan ucapan partisipan dan interpretasi peneliti. Jangan mengarang kutipan atau menyatakan saturasi tanpa alasan metodologis.

## Output
Panduan wawancara, codebook, tabel kutipan-kode-tema, narasi temuan, refleksi, dan keterbatasan.
