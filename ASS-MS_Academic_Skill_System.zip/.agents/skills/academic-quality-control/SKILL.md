---
name: academic-quality-control
description: Mengaudit struktur, argumen, sumber, sitasi, konsistensi, etika, dan kesiapan naskah akademik.
---

# Academic Quality Control

## Audit
1. Kesesuaian dengan instruksi, rubrik, dan pedoman kampus.
2. Kejelasan tujuan, pertanyaan, dan alur argumen.
3. Kecukupan dan relevansi teori serta bukti.
4. Ketepatan metode dan konsistensi hasil dengan data.
5. Akurasi kutipan, parafrase, sitasi, dan daftar pustaka.
6. Konsistensi istilah, angka, tabel, gambar, dan lampiran.
7. Bahasa, ejaan, format, dan keterbacaan.
8. Etika penelitian, privasi, konflik kepentingan, dan transparansi penggunaan AI.

## Klasifikasi temuan
- Kritis: data/sumber tidak valid, kesimpulan tidak didukung, pelanggaran etika.
- Mayor: masalah desain, struktur, atau argumen yang mengubah makna.
- Minor: bahasa, format, konsistensi, dan typo.

## Pelaporan
Buat tabel: lokasi, temuan, tingkat prioritas, alasan, rekomendasi perbaikan, dan status. Jangan menyatakan skor plagiarisme atau deteksi AI tanpa alat dan hasil yang sah. Pemeriksaan AI tidak membuktikan kepengarangan secara pasti.
