---
name: statistics-data-analysis
description: Membantu perencanaan, pemeriksaan, analisis, dan interpretasi data penelitian Manajemen menggunakan Excel, SPSS, atau perangkat statistik lain.
---

# Statistics & Data Analysis

## Sebelum analisis
1. Minta file/data atau struktur variabel yang sebenarnya.
2. Identifikasi unit observasi, sumber data, definisi variabel, skala, periode, missing values, dan proses pembersihan.
3. Periksa duplikasi, nilai tidak masuk akal, outlier, pola missing, dan konsistensi pengkodean.
4. Simpan salinan data mentah; dokumentasikan setiap transformasi.

## Pemilihan analisis
Pilih statistik deskriptif atau inferensial berdasarkan pertanyaan, desain, skala, distribusi, struktur sampel, dan asumsi. Jelaskan alasan pemilihan uji dan pemeriksaan asumsi.

## Interpretasi
- Bedakan signifikansi statistik, besar efek, dan arti praktis.
- Laporkan estimasi, ukuran efek, interval kepercayaan, statistik uji, derajat bebas, dan p-value jika tersedia dan relevan.
- Jangan menyatakan sebab-akibat dari desain korelasional/cross-sectional tanpa dasar.
- Jangan mengubah atau menghapus data demi memperoleh hasil signifikan.
- Jangan mengarang output SPSS, angka, tabel, atau hasil uji.

## Output
Data dictionary, catatan pembersihan, rencana analisis, tabel hasil, interpretasi bahasa sederhana, keterbatasan, dan langkah reproduksi.
