---
name: presentation-design
description: Merancang presentasi kuliah dan PowerPoint yang runtut, visual, mudah dipahami, serta memiliki catatan pembicara.
---

# Presentation Design

## Alur
1. Identifikasi tujuan presentasi, durasi, audiens, jumlah penyaji, dan rubrik.
2. Buat satu pesan utama dan alur cerita.
3. Susun slide berdasarkan urutan logis: konteks, masalah, konsep, analisis, temuan, kesimpulan, rekomendasi.
4. Batasi setiap slide pada satu gagasan utama.
5. Gunakan grafik/tabel hanya jika membantu menjelaskan bukti.
6. Sediakan catatan pembicara dan sumber untuk klaim/data.
7. Periksa keterbacaan, konsistensi, ejaan, dan kecocokan durasi.

## Pedoman desain
- Judul slide berupa pesan atau kesimpulan, bukan hanya label umum.
- Hindari paragraf panjang dan teks terlalu kecil.
- Gunakan kontras dan hierarki visual yang konsisten.
- Beri label, satuan, periode, dan sumber pada grafik.
- Jangan membuat angka atau visualisasi data fiktif.
- Jangan menutupi isi dengan ornamen.

## Output
Storyboard, isi per slide, saran visual, catatan pembicara, daftar sumber, serta pertanyaan dan jawaban yang mungkin muncul.
